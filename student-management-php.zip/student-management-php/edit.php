<?php
include 'db.php';
$id = intval($_GET['id']);
$result = mysqli_query($conn, "SELECT * FROM students WHERE id=$id");
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Student</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Edit Student</h2>
    <form method="POST" action="">
        <input type="text" name="name" value="<?php echo $row['name']; ?>" required><br><br>
        <input type="email" name="email" value="<?php echo $row['email']; ?>" required><br><br>
        <input type="text" name="phone" value="<?php echo $row['phone']; ?>" required><br><br>
        <input type="text" name="course" value="<?php echo $row['course']; ?>" required><br><br>
        <input type="submit" name="submit" value="Update Student">
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $course = mysqli_real_escape_string($conn, $_POST['course']);

        $sql = "UPDATE students SET name='$name', email='$email', phone='$phone', course='$course' WHERE id=$id";
        if (mysqli_query($conn, $sql)) {
            header('Location: index.php');
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }
    ?>
</body>
</html>
