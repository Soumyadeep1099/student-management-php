<?php
include 'db.php';

// Handle Delete Student
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    $sql = "DELETE FROM students WHERE id = $id";
    if (mysqli_query($conn, $sql)) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Student List</h2>
    <a href="add.php" class="add-btn">+ Add New Student</a>
    <table>
        <thead>
            <tr>
                <th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Course</th><th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $result = mysqli_query($conn, "SELECT * FROM students");
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['phone']}</td>
                    <td>{$row['course']}</td>
                    <td>
                        <a href='edit.php?id={$row['id']}' class='edit-btn'>Edit</a>
                        <a href='index.php?delete_id={$row['id']}' onclick=\"return confirm('Are you sure you want to delete this student?');\" class='delete-btn'>Delete</a>
                    </td>
                  </tr>";
        }
        ?>
        </tbody>
    </table>
</body>
</html>
